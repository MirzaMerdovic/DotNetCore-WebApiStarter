﻿namespace $safeprojectname$.Configuration
{
    public class ConnectionStrings 
    {
        public string ApiDb { get; set; }

        public string Api2Db { get; set; }
    }
}